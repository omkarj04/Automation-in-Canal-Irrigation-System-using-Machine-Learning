package com.example.jalniti;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.regbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newactivity();
            }
        });

        button = findViewById(R.id.cntbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newactivity2();
            }
        });
    }

    private void newactivity()
    {
        String localhostUrl = "http://localhost:8080/Canel/UserHome.jsp";  // Replace with your localhost URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(localhostUrl));
        startActivity(intent);
    }

    public void OpenUrl(String url)
    {
        Uri uri = Uri.parse(url);
        Intent launchWeb = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(launchWeb);
    }

    public void newactivity2(){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

}